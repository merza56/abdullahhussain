
  # موقع إلكتروني لمهارات براند دزاينر

  This is a code bundle for موقع إلكتروني لمهارات براند دزاينر. The original project is available at https://www.figma.com/design/aPMcwH4PkwLbNMpaTANH3v/%D9%85%D9%88%D9%82%D8%B9-%D8%A5%D9%84%D9%83%D8%AA%D8%B1%D9%88%D9%86%D9%8A-%D9%84%D9%85%D9%87%D8%A7%D8%B1%D8%A7%D8%AA-%D8%A8%D8%B1%D8%A7%D9%86%D8%AF-%D8%AF%D8%B2%D8%A7%D9%8A%D9%86%D8%B1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  